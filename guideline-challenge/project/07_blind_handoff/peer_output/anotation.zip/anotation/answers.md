# Blind handoff — Trả lời 5 câu hỏi

**Guideline:** v2 · **Export:** `anotation/annotations.xml` (CVAT for images 1.1, 5 ảnh, 13 box, chỉ dùng Shape)

Export được giữ nguyên như lúc gắn nhãn blind; các chỗ nghi sai được ghi dưới đây làm bằng chứng cho owner, không sửa lại.

---

## 1. Rule nào rõ nhất / giúp quyết định nhanh nhất?

- **Quy tắc ưu tiên 1 và 3 (§4):** "Tam giác ngược là `give_way`" và "Biển tròn xanh có mũi tên là `other`". Hai rule này chỉ dựa vào hình dạng + màu nên quyết định gần như tức thì.
  - GTS21: biển tròn xanh chỉ hướng xiên trái → `other` ngay.
  - GTS24: biển tròn xanh mũi tên thẳng → `other` ngay.
- **"Mỗi mặt biển là một box" (§2)** kèm ví dụ GTS18/GTS01: giúp tách ngay cụm 3 panel chỉ hướng ở GTS21 thành 3 box riêng, và cụm 2 biển chồng nhau ở GTS04 thành 2 box.
- **Rule loại trừ quảng cáo/biển cửa hàng (§5):** EINGANG/WARENAUSGABE (GTS17), Veltins (GTS21), logo Deutsche Bank (GTS24) đều bỏ qua mà không phải suy nghĩ.

## 2. Rule nào mơ hồ hoặc phải tự suy diễn?

- **Ranh giới `other` và ngoài scope.** "Biển tên đường" bị loại nhưng "biển chỉ dẫn/thông tin" lại phải label. Biển chỉ dẫn có tên địa danh (panel chỉ hướng ở GTS15, biển "Süd" nhỏ ở GTS17) thì thuộc loại nào? Guideline không có tiêu chí phân biệt.
- **"Chevron" gồm những gì?** Cọc tiêu sọc xanh-trắng (Leitbake) ở GTS21 là thiết bị giao thông official, nhưng có tính là "chevron/mặt biển" không? Guideline không nói, và mình đã tự quyết định **không** label.
- **Lớp biển tròn đỏ cấm không nằm trong bảng taxonomy.** Việc "biển cấm vượt → `other`" chỉ xuất hiện trong ví dụ GTS01 và ở dòng mô tả `other`. Các biển cấm tròn viền đỏ khác (cấm xe tải vượt, cấm đỗ, v.v.) phải tự suy ra, và biển cấm vượt xe tải ở GTS04 bị nhầm thành `warning`.
- **"Đủ bằng chứng" và `unknown` không có tiêu chí thao tác.** §6 cấm dùng ngưỡng pixel/% nhưng không đưa ra câu hỏi kiểm tra thay thế. Với các biển nhỏ ở GTS24 (khoảng 15 px), mỗi người sẽ chọn một mức khác nhau: bỏ qua, `unknown` hoặc class cụ thể.
- **Cờ `occluded` của CVAT không được nhắc đến:** không rõ có cần bật cờ này khi biển bị che không.

## 3. Sample nào khiến guideline "vỡ"?

- **GTS17 — hai tam giác ngược màu xám phía trên biển `no_entry`.** Màu xám đều, không thấy viền đỏ, nên nhiều khả năng là **mặt sau** của biển nhường đường. Tuy nhiên ở độ phân giải này không phân biệt chắc được mặt trước hay mặt sau:
  - Nếu là mặt sau thì phải IGNORE.
  - Nếu là mặt trước bị loá thì là `give_way`.
  - `unknown` không dùng được, vì `unknown` yêu cầu "chắc chắn là mặt biển official", tức là đã xác nhận được mặt trước.

  Guideline không có nhánh cho trường hợp "không biết đang nhìn mặt nào", nên cả 3 lựa chọn LABEL / IGNORE / UNKNOWN đều không khớp. Mình chọn IGNORE.
- **GTS04 — biển tròn đỏ có hình xe tải (cấm vượt xe tải) dưới biển 120.** Ảnh chụp trong sương mù, biển nhỏ, và biển nằm ngay dưới biển tốc độ giống bố cục ví dụ GTS18 ("warning phía trên speed_limit"). Vì vậy mình đã gán nhầm thành `warning` cho cả hai bên. Guideline không có dòng nào nói "biển tròn viền đỏ không phải `warning`". Mẫu này cũng có biển chỉ dẫn xanh lớn trên cao (Bochum-Gerthe 900 m) và một biển xanh ở xa; mình đã bỏ sót cả hai, vì trong đầu vẫn còn nghi ngờ "biển chỉ dẫn có thuộc scope không".
- **GTS15 — cụm panel chỉ hướng nhỏ, bị cây che một phần.** Khó xác định biên riêng từng panel, nên không biết phải vẽ bao nhiêu box. Mình đã bỏ sót toàn bộ cụm.

## 4. Attribute/default nào trong CVAT dễ gây thao tác sai?

- **Label mặc định là `stop`** (đứng đầu `cvat_labels.json`). Khi vẽ nhanh liên tiếp mà quên đổi label, box sẽ thành `stop`, và đây là loại lỗi reviewer khó phát hiện nếu chỉ nhìn màu.
- **Không có attribute nào**, và cờ `occluded` luôn để 0 trong export (13/13 box). Owner không phân biệt được biển bị che mà mình đã xem xét với biển mình không để ý. Cần hoặc bỏ hẳn cờ này, hoặc quy định rõ khi nào phải bật.
- **`other` và `unknown` đứng cạnh nhau**, và `unknown` màu xám `#757575` dễ bị hiểu là "ignore/bỏ qua". Nguy cơ chọn nhầm giữa hai class này là cao nhất.
- **`warning` (#FDD835 vàng) và `give_way` (#FB8C00 cam)** có màu gần nhau, khó soát lại lỗi nhầm hai class này bằng mắt.
- **Không có gì chặn việc chuyển sang Track mode.** Guideline yêu cầu Shape, nhưng CVAT vẫn cho phép tạo track, và khi đó export format lại khác (README bước 3).

## 5. Một thay đổi cụ thể giúp annotator mới ít hỏi hơn?

**Thêm vào CVAT Guide một bảng "cây quyết định + ảnh mẫu IGNORE"**, đặt ngay đầu guideline:

1. Có thấy mặt mang thông tin (màu, ký hiệu, viền) không? Nếu chỉ thấy khối xám/kim loại đồng màu → **IGNORE (mặt sau)**. Nếu không chắc mặt trước hay mặt sau → **IGNORE**, và ghi vào edge case.
2. Có phải biển giao thông official không (không phải quảng cáo, tên đường, logo)? → nếu không thì **IGNORE**.
3. Chọn theo hình dạng:
   - tam giác ngược → `give_way`
   - tam giác đứng → `warning`
   - bát giác → `stop`
   - **tròn viền đỏ**: có số → `speed_limit`, vạch trắng ngang → `no_entry`, còn lại (cấm vượt, cấm xe tải, …) → `other`
   - tròn xanh / chữ nhật / chevron / panel phụ → `other`
4. Chắc là biển nhưng không xác định được hình/ký hiệu → `unknown`.

Kèm theo mỗi nhánh một thumbnail, đặc biệt là các ca IGNORE: mặt sau biển (như GTS17), biển cửa hàng (EINGANG, Veltins), đèn giao thông. Ngoài ra, bổ sung một dòng nói rõ **biển chỉ dẫn hướng/địa danh là `other`, chỉ biển tên phố gắn tại góc đường mới bị loại**, và một dòng về cọc tiêu (Leitbake): label hay không.

---

## Clarification log (câu hỏi ghi lại, không hỏi owner trong lúc làm)

| # | Ảnh | Câu hỏi | Quyết định đã chọn |
|---|---|---|---|
| 1 | GTS17 | Tam giác xám phía trên biển no_entry là mặt trước hay mặt sau? Không chắc thì xử lý thế nào? | IGNORE |
| 2 | GTS17 | Biển "Süd" nhỏ trên cột là biển chỉ dẫn (`other`) hay biển tên đường (loại)? | IGNORE |
| 3 | GTS21 | Cọc tiêu sọc xanh-trắng có tính là chevron/mặt biển không? | IGNORE |
| 4 | GTS04 | Biển tròn đỏ cấm vượt xe tải: có cần rule riêng "tròn viền đỏ không phải warning"? | Đã gán `warning` (sau khi xem lại: nhiều khả năng là sai, đúng ra là `other`) |
| 5 | GTS04, GTS15 | Biển chỉ dẫn xanh có tên địa danh/khoảng cách có bắt buộc label không? | Bỏ sót (không label) |
| 6 | GTS24 | Biển rất nhỏ (~15 px) nhận ra được màu/hình tròn nhưng không đọc được ký hiệu: `unknown` hay IGNORE? | Bỏ sót (không label) |
| 7 | Tất cả | Có cần bật cờ `occluded` cho biển bị che không? | Để mặc định 0 |
